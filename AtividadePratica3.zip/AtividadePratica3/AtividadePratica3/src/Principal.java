public class Principal {
    public static void main(String[] args) {
        SistemaGerenciamento sistema = new SistemaGerenciamento();
        sistema.menuPrincipal();
    }
}
