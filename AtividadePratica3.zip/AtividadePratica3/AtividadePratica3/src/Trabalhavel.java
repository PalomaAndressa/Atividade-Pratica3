public interface Trabalhavel {
    void trabalhar();
    void relatarProgresso();
}


